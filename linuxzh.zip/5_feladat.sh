#!/bin/bash

fajl=$1

while read sor
do
echo $sor | wc -w
done < $fajl