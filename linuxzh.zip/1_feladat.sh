#!/bin/bash

mkdir Zala Veszprém Vas
cd Zala
echo "Zalaegerszeg" > megyeszékhely.txt
cp megyeszékhely.txt ../Veszprém
cd ../Vas
ln -s ../Zala/megyeszékhely.txt zala.txt
cd ..
rm -r Veszprém