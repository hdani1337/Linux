#!/bin/bash
cat film
cat film | cut -c 6-9
cat film | cut -d\; -f 4
cat film | grep 18$
cat film | grep 12$ |cut -d\; -f 1